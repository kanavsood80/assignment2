const fs = require('fs');

var db=require('../database');

module.exports = {
    add: (req, res) => {
        res.render('add.ejs', {
            title: "Welcome! Add a new contact"
            ,message: ''
        });
    },
    addContact: (req, res) => {

        let message = '';
        let first_name = req.body.first_name;
        let last_name = req.body.last_name;
        let gender = req.body.gender;
        let email_address = req.body.email_address;

        let usernameQuery = "SELECT * FROM registration WHERE email_address = '" + email_address + "'";

        db.query(usernameQuery, (err, result) => {
            if (err) {
                return res.status(500).send(err);
            }
            if (result.length > 0) {
                message = 'Email already exists';
                res.render('add.ejs', {
                    message,
                    title: "Welcome! Add a new contact"
                });
            } else {
                
                       // send the details to the database
                        let query = "INSERT INTO registration (first_name, last_name, gender, email_address) VALUES (" +
                           '"'+ req.body.first_name + '", "' + req.body.last_name + '", "' + req.body.gender + '", "' + req.body.email_address+ '")' ;
                        db.query(query, (err, result) => {
                            if (err) {
                                return res.status(500).send(err);
                            }
                            res.redirect('/');
                        });
                    }
                });
            },
        
    
    edit: (req, res) => {
       
        let query = "SELECT * FROM registration";
        db.query(query, (err, result) => {
            if (err) {
                return res.status(500).send(err);
            }
            res.render('edit.ejs', {
                title: "Edit Contact"
                ,registration: result[0]
                ,message: ''
            });
        });
    },
    editContact: (req, res) => {
        let registrationId = req.params.id;
        let first_name = req.body.first_name;
        let last_name = req.body.last_name;
        let gender = req.body.gender;

        let query = "UPDATE registration SET first_name = '" + first_name + "', last_name = '" + last_name + "', gender = '" + gender + "' WHERE registration.id = '" + registrationId + "'";
        db.query(query, (err, result) => {
            if (err) {
                return res.status(500).send(err);
            }
            res.redirect('/');
        });
    },
    deletePage: (req, res) => {
        let Id = req.params.id;
        let deleteUserQuery = 'DELETE FROM registration WHERE id = "' + Id + '"';

                db.query(deleteUserQuery, (err, result) => {
                    if (err) {
                        return res.status(500).send(err);
                    }
                    res.redirect('/');
                });
            
        }
}
    
