
/**
 * file: router/index.js
 * name: Kanav sood
 * student id: 
 * date: 25-Apr-2021
*/
var express = require('express');
var router = express.Router();
var db=require('../database');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Kanav Sood - Home' });
});

router.get('/about', function(req, res, next) {
  res.render('about', { title: 'Kanav Sood - About me' });
});

router.get('/projects', function(req, res, next) {
  res.render('projects', { title: 'Kanav Sood - Projects' });
});

router.get('/services', function(req, res, next) {
  res.render('services', { title: 'Kanav Sood - Services' });
});

router.get('/contact', function(req, res, next) {
  res.render('contact', { title: 'Kanav Sood - Contact' });
});

router.post('/contact', function(req, res, next) {
  console.log('form submitted', req.body)
  res.redirect('/')
});

/* GET users listing. */
router.get('/login', function(req, res, next) {
  res.render('login-form');
});

router.post('/login', function(req, res){
    var emailAddress = req.body.email_address;
    var password = req.body.password;
    var sql='SELECT * FROM registration WHERE email_address =? AND password =?';
    db.query(sql, [emailAddress, password], function (err, data, fields) {
        if(data.length>0){
            req.session.loggedinUser= true;
            req.session.emailAddress= emailAddress;
            res.redirect('/contact-list');
        }else{
            res.render('login-form',{alertMsg:"Your Email Address or password is wrong"});
        }
    })
});

router.get('/contact-list', function(req, res, next) {
	var sql='SELECT * FROM registration ORDER BY first_name ASC';
    db.query(sql, function (err, data, fields) {
		 
            res.render('contact-list', { title: 'Contact list', registration: data});
        
   
  });
});
  



module.exports = router;
